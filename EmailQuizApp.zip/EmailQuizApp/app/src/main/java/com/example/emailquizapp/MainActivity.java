package com.example.emailquizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int correctAnswers = 0;
    //int q1(/2/3/4)point makes sure that point for for the question counts only once
    int q1point = 0;
    int q2point = 0;
    int q3point = 0;
    int q4point = 0;
    boolean isClickedQ1 = false;
    boolean isClickedQ2 = false;
    boolean isClickedQ3 = false;
    boolean isClickedQ4 = false;
    String correctAns4 = "simple mail transfer protocol";

    RadioButton question2RadioButton;
    RadioGroup question2RadioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        question2RadioGroup=(RadioGroup)findViewById(R.id.radioButtonGroup);
    }


    //displays toast for correct answer
    public void displayCorrectAnswerToast(View view){
        Context context = getApplicationContext();
        String toastText = getString(R.string.toast_correct);
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, toastText, duration);

        toast.show();
    }
    //displays toast when answer is incorrect
    public void displayWrongAnswerToast(View view){
        Context context = getApplicationContext();
        String toastText = getString(R.string.toast_wrong);
        int duration = Toast.LENGTH_LONG;

        Toast toast = Toast.makeText(context, toastText, duration);

        toast.show();
    }




//checking if all correct answers are checked for question nr 1 (answers 1,2,3)

    public void submitQuestion1(View view) {

        //check if answer has been submitted
        if (!isClickedQ1) {
            isClickedQ1 = true;

            Button Q1Button = (Button) findViewById(R.id.q1_button);
            Q1Button.setBackgroundColor(getResources().getColor(R.color.colorButtonInactive));

            CheckBox q1a1 = (CheckBox) findViewById(R.id.q1_answer_1);
            boolean hasQ1A1 = q1a1.isChecked();

            CheckBox q1a2 = (CheckBox) findViewById(R.id.q1_answer_2);
            boolean hasQ1A2 = q1a2.isChecked();

            CheckBox q1a3 = (CheckBox) findViewById(R.id.q1_answer_3);
            boolean hasQ1A3 = q1a3.isChecked();

            CheckBox q1a4 = (CheckBox) findViewById(R.id.q1_answer_4);
            boolean hasQ1A4 = q1a4.isChecked();

            if (q1point == 0) {
                if (hasQ1A1 == true && hasQ1A2 == true && hasQ1A3 == true && hasQ1A4 == false) {
                    q1point = 1;
                    correctAnswers += q1point;
                    displayCorrectAnswerToast(view);
                } else {
                    q1point = 0;
                    displayWrongAnswerToast(view);
                }
            }
        } else {
            {
                Context context = getApplicationContext();
                String toastText = "answer already submitted!";
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, toastText, duration);

                toast.show();
            }
        }
        Log.v("MainActivity", "ile dobrych odp: " + correctAnswers);
    }


    // checking if correct answer is checked for question nr 2 (answers 2)
    public void submitQuestion2(View view) {

        //check if answer has been submitted
        if (!isClickedQ2) {

            isClickedQ2 = true;

            Button Q2Button = (Button) findViewById(R.id.q2_button);
            Q2Button.setBackgroundColor(getResources().getColor(R.color.colorButtonInactive));

            int selectedId = question2RadioGroup.getCheckedRadioButtonId();
            question2RadioButton = (RadioButton) findViewById(selectedId);
            Log.v("MainActivity", "button ID : " + selectedId);

            if (q2point == 0) {
                if (selectedId == 2131165313) {
                    q2point = 1;
                    correctAnswers += q2point;
                    displayCorrectAnswerToast(view);
                } else {
                    q2point = 0;
                    displayWrongAnswerToast(view);
                }
                Log.v("MainActivity", "ile dobrych odp: " + correctAnswers);
            }
        }else{

                Context context = getApplicationContext();
                String toastText = "answer already submitted!";
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, toastText, duration);

                toast.show();
            }
    }

    //checking if all correct answers are checked for question nr 3 (answers 1,2)
    public void submitQuestion3(View view) {

        //check if answer has been submitted
        if(!isClickedQ3){

            isClickedQ3 = true;

            Button Q3Button = (Button) findViewById(R.id.q3_button);
            Q3Button.setBackgroundColor(getResources().getColor(R.color.colorButtonInactive));

            CheckBox q3a1 = (CheckBox) findViewById(R.id.q3_answer_1);
            boolean hasQ3A1 = q3a1.isChecked();

            CheckBox q3a2 = (CheckBox) findViewById(R.id.q3_answer_2);
            boolean hasQ3A2 = q3a2.isChecked();

            CheckBox q3a3 = (CheckBox) findViewById(R.id.q3_answer_3);
            boolean hasQ3A3 = q3a3.isChecked();

            CheckBox q3a4 = (CheckBox) findViewById(R.id.q3_answer_4);
            boolean hasQ3A4 = q3a4.isChecked();


            if (q3point == 0) {
                if (hasQ3A1 == true && hasQ3A2 == true && hasQ3A3 == false && hasQ3A4 == false) {
                    q3point = 1;
                    correctAnswers += q3point;
                    displayCorrectAnswerToast(view);
                } else {
                    q3point = 0;
                    displayWrongAnswerToast(view);
                }
                Log.v("MainActivity", "ile dobrych odp: " + correctAnswers);
            }
        }else{

            Context context = getApplicationContext();
            String toastText = "answer already submitted!";
            int duration = Toast.LENGTH_LONG;

            Toast toast = Toast.makeText(context, toastText, duration);

            toast.show();
        }
    }

    // checking if correct answer is checked for question nr 2 (answers 2)
    public void submitQuestion4(View view) {

        //check if answer has been submitted
        if (!isClickedQ4) {

            isClickedQ4 = true;

            Button Q4Button = (Button) findViewById(R.id.q4_button);
            Q4Button.setBackgroundColor(getResources().getColor(R.color.colorButtonInactive));


            if (q4point == 0) {

                EditText userNameInput = (EditText) findViewById(R.id.q4_answer);
                String ans4 = userNameInput.getText().toString();
                Log.v("MainActivity", "user name: " + ans4);

                if (ans4.equalsIgnoreCase(correctAns4)) {
                    q4point = 1;
                    correctAnswers += q4point;
                    displayCorrectAnswerToast(view);
                }else {
                    q4point = 0;
                    displayWrongAnswerToast(view);
                }
                Log.v("MainActivity", "ile dobrych odp: " + correctAnswers);
            }else{

                Context context = getApplicationContext();
                String toastText = "answer already submitted!";
                int duration = Toast.LENGTH_LONG;

                Toast toast = Toast.makeText(context, toastText, duration);

                toast.show();
            }
        }
    }



    //method reset all answers and inputs
    public void resetQuiz(View view){

        setContentView(R.layout.activity_main);

        correctAnswers = 0;
        //int q1(/2/3/4)point makes sure that point for for the question counts only once
        q1point = 0;
        q2point = 0;
        q3point = 0;
        q4point = 0;
        isClickedQ1 = false;
        isClickedQ2 = false;
        isClickedQ3 = false;
        isClickedQ4 = false;
    }

    public void composeSummary(String addresses, String subject, String emailBody) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, emailBody);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void submitAll(View view){
        EditText userName = (EditText) findViewById(R.id.user_name);
        String usrName = userName.getText().toString();
        Log.v("MainActivity", "user name: " + usrName);
        createQuizSummary(usrName);

    }
    public String createQuizSummary(String name) {
        String address = "ala@makota.com";
        String subject = "Quiz summary";
        String summaryMessage = "";
        if(correctAnswers<=2){
            summaryMessage = "Try again ";
        }else summaryMessage = "Congratulations " ;
        summaryMessage += name +"!";
        summaryMessage += "\nYou scored " + correctAnswers + " points!";
        String content = summaryMessage;
        composeSummary(address, subject, content);
        return(content);
    }


}
